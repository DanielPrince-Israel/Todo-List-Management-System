TO-DO LIST MANAGEMENT SYSTEM
=============================

Requirements
------------
- Python 3
- Tkinter (usually included with standard Python installations)
- No third-party packages are required.

How to run
----------
1. Extract this folder if you downloaded the ZIP.
2. Open the folder in your Python environment.
3. Run:
       python todo.py
4. Type a task and click Add Task.
5. Select a task in the table to mark it completed or delete it.

Data storage
------------
Tasks are saved automatically in tasks.json in the same folder as todo.py.
The file is created after the first task is added.

Features
--------
- Add tasks
- View tasks in a table
- Mark selected tasks as completed
- Delete selected tasks
- Clear all tasks
- Save and reload tasks using JSON

Note
----
This is a beginner educational project. If you use an online compiler, Tkinter
may not be supported because it needs a desktop graphical environment. Run it
on a laptop with Python and Tkinter available.
