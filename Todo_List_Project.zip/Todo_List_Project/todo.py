import json
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

DATA_FILE = Path(__file__).with_name("tasks.json")


class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List Management System")
        self.root.geometry("760x560")
        self.root.minsize(620, 460)
        self.root.configure(bg="#f3f6fb")
        self.tasks = self.load_tasks()

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Treeview", rowheight=32, font=("Arial", 10))
        style.configure("Treeview.Heading", font=("Arial", 10, "bold"))

        header = tk.Frame(root, bg="#243b64", padx=22, pady=18)
        header.pack(fill="x")
        tk.Label(header, text="TO-DO LIST MANAGER", bg="#243b64",
                 fg="white", font=("Arial", 20, "bold")).pack(anchor="w")
        tk.Label(header, text="Organize your daily tasks in one place",
                 bg="#243b64", fg="#dce7fa", font=("Arial", 10)).pack(anchor="w", pady=(5, 0))

        main = tk.Frame(root, bg="#f3f6fb", padx=22, pady=18)
        main.pack(fill="both", expand=True)

        entry_row = tk.Frame(main, bg="#f3f6fb")
        entry_row.pack(fill="x", pady=(0, 14))
        self.task_entry = tk.Entry(entry_row, font=("Arial", 12), relief="solid", bd=1)
        self.task_entry.pack(side="left", fill="x", expand=True, ipady=9, padx=(0, 10))
        self.task_entry.bind("<Return>", lambda event: self.add_task())
        tk.Button(entry_row, text="Add Task", command=self.add_task,
                  bg="#2878d0", fg="white", activebackground="#1e64b2",
                  activeforeground="white", relief="flat", padx=18,
                  font=("Arial", 10, "bold"), cursor="hand2").pack(side="right", ipady=7)

        columns = ("task", "status")
        self.table = ttk.Treeview(main, columns=columns, show="headings", selectmode="browse")
        self.table.heading("task", text="TASK")
        self.table.heading("status", text="STATUS")
        self.table.column("task", width=480, anchor="w")
        self.table.column("status", width=130, anchor="center")
        self.table.pack(fill="both", expand=True)

        controls = tk.Frame(main, bg="#f3f6fb")
        controls.pack(fill="x", pady=(14, 0))
        self.make_button(controls, "Mark Completed", self.complete_task, "#23865b").pack(side="left", padx=(0, 8))
        self.make_button(controls, "Delete Task", self.delete_task, "#c94b4b").pack(side="left", padx=8)
        self.make_button(controls, "Clear All", self.clear_tasks, "#68758a").pack(side="left", padx=8)

        self.status_label = tk.Label(main, text="", bg="#f3f6fb",
                                     fg="#52627a", font=("Arial", 9))
        self.status_label.pack(anchor="w", pady=(12, 0))
        self.refresh_table()

    def make_button(self, parent, text, command, color):
        return tk.Button(parent, text=text, command=command, bg=color, fg="white",
                         activebackground=color, activeforeground="white",
                         relief="flat", padx=13, pady=9,
                         font=("Arial", 9, "bold"), cursor="hand2")

    def load_tasks(self):
        if DATA_FILE.exists():
            try:
                with DATA_FILE.open("r", encoding="utf-8") as file:
                    data = json.load(file)
                    return data if isinstance(data, list) else []
            except (json.JSONDecodeError, OSError):
                messagebox.showwarning("Data warning", "Could not read tasks.json. Starting with an empty list.")
        return []

    def save_tasks(self):
        try:
            with DATA_FILE.open("w", encoding="utf-8") as file:
                json.dump(self.tasks, file, indent=4, ensure_ascii=False)
        except OSError as error:
            messagebox.showerror("Save error", f"Could not save tasks:\n{error}")

    def refresh_table(self):
        for item in self.table.get_children():
            self.table.delete(item)
        for index, task in enumerate(self.tasks):
            status = "Completed" if task.get("completed", False) else "Pending"
            self.table.insert("", "end", iid=str(index), values=(task.get("title", ""), status))
        pending = sum(not task.get("completed", False) for task in self.tasks)
        completed = len(self.tasks) - pending
        self.status_label.config(
            text=f"Total tasks: {len(self.tasks)}     Pending: {pending}     Completed: {completed}"
        )

    def selected_index(self):
        selected = self.table.selection()
        if not selected:
            messagebox.showinfo("Select a task", "Please select a task from the list first.")
            return None
        return int(selected[0])

    def add_task(self):
        title = self.task_entry.get().strip()
        if not title:
            messagebox.showwarning("Empty task", "Please type a task before clicking Add Task.")
            return
        self.tasks.append({"title": title, "completed": False})
        self.save_tasks()
        self.task_entry.delete(0, tk.END)
        self.refresh_table()

    def complete_task(self):
        index = self.selected_index()
        if index is None:
            return
        self.tasks[index]["completed"] = True
        self.save_tasks()
        self.refresh_table()

    def delete_task(self):
        index = self.selected_index()
        if index is None:
            return
        if messagebox.askyesno("Confirm delete", "Delete the selected task?"):
            self.tasks.pop(index)
            self.save_tasks()
            self.refresh_table()

    def clear_tasks(self):
        if not self.tasks:
            messagebox.showinfo("No tasks", "There are no tasks to clear.")
            return
        if messagebox.askyesno("Confirm clear", "Delete all tasks? This cannot be undone."):
            self.tasks.clear()
            self.save_tasks()
            self.refresh_table()


if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()
